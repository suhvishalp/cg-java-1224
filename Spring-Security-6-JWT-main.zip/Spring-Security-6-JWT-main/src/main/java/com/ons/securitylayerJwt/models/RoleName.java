package com.ons.securitylayerJwt.models;


public enum RoleName {

    SUPERADMIN , ADMIN , USER;

}

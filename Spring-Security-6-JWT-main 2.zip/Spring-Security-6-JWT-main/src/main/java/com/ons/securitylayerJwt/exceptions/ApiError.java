package com.ons.securitylayerJwt.exceptions;

import java.util.List;

import org.springframework.http.HttpStatus;

public class ApiError {
	private String statusCode;
    private HttpStatus status;
    private String message;
    private List<ErrorDetail> errors;

    public ApiError() {
    }

    public ApiError(HttpStatus status, String message, List<ErrorDetail> errors) {
        this.status = status;
        this.message = message;
        this.errors = errors;
    }

    public ApiError(HttpStatus status, String message, ErrorDetail error) {
        this.status = status;
        this.message = message;
        this.errors = List.of(error);
    }

    // Getters and setters
    public HttpStatus getStatus() {
        return status;
    }
    public void setStatus(HttpStatus status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public List<ErrorDetail> getErrors() {
        return errors;
    }
    public void setErrors(List<ErrorDetail> errors) {
        this.errors = errors;
    }
}
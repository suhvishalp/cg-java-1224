package com.ons.securitylayerJwt.presentation;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ons.securitylayerJwt.dto.UserDTO;
import com.ons.securitylayerJwt.models.User;
import com.ons.securitylayerJwt.persistence.IUserRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminRestController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private IUserRepository userRepository;

	// RessourceEndPoint:http://localhost:8087/api/admin/hello
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello";
	}

	
	@GetMapping("/users")
	public List<UserDTO> getAllUsers(){
		List<User> users = userRepository.findAll();
		List<UserDTO> userDtoList = new ArrayList<>();
		
		for(User user: users) 
			userDtoList.add(modelMapper.map(user, UserDTO.class));
	
		return userDtoList;
			
	}
}

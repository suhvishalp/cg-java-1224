// src/pages/AdminLink2.js
import React from 'react';

const AdminLink2 = () => {
  return (
    <div className="container mt-4">
      <h2>Admin Link2</h2>
      <p>This is the content for Admin Link2.</p>
    </div>
  );
};

export default AdminLink2;

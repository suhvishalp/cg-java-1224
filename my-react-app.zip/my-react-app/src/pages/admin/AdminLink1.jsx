// src/pages/AdminLink1.js
import React from 'react';

const AdminLink1 = () => {
  return (
    <div className="container mt-4">
      <h2>Admin Link1</h2>
      <p>This is the content for Admin Link1.</p>
    </div>
  );
};

export default AdminLink1;

import React from 'react';

const UserLink2 = () => {
  return (
    <div className="container mt-4">
      <h2>UserLink2</h2>
      <p>This is the content for User Link2.</p>
    </div>
  );
};

export default UserLink2;

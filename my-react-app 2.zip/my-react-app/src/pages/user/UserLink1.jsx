import React from 'react';

const UserLink1 = () => {
  return (
    <div className="container mt-4">
      <h2>UserLink1</h2>
      <p>This is the content for User Link1.</p>
    </div>
  );
};

export default UserLink1;
